function [F1] = ComputeF_trans_CASE3(scores1,h1,p)

F1 = zeros(1,length(scores1));

for i = 1:length(scores1)
    F1(i) = length(scores1)*mean((1-p).*normcdf(scores1(i),scores1,h1))/sum(1-p);
end

end