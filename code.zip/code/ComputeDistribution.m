function [p,pi0,pi1,h0,h1,f0,f1,F0,F1,A,pk] = ComputeDistribution(Targetscores,TargetGroupType,Decoyscores,DecoyGroupType,P,ems,ppi0,ppi1,hh1)

Targetscores_group = Targetscores(TargetGroupType==0);
Decoyscores_group = Decoyscores(DecoyGroupType==0);

[p.global,pi0.global,pi1.global,h0.global,h1.global,f0.global,f1.global] = SemiParametricFitting(Decoyscores,Targetscores,ems.global,ppi0,ppi1,hh1.global);
[p.separate,pi0.separate,pi1.separate,h0.separate,h1.separate,f0.separate,f1.separate] = SemiParametricFitting(Decoyscores_group,Targetscores_group,ems.separate,ppi0,ppi1,hh1.separate);


[F0.global,F1.global] = ComputeF(Targetscores,Decoyscores,h0.global,h1.global,p.global);

[F0.separate,F1.separate] = ComputeF(Targetscores_group,Decoyscores_group,h0.separate,h1.separate,p.separate);



A = -(pi0.global*(P(1))*(1-F0.global(TargetGroupType==0))+pi0.global*(P(1)*Targetscores(TargetGroupType==0)+P(2)).*(-f0.global(TargetGroupType==0)));
pk = sum(TargetGroupType==0)/length(Targetscores);
end


