function DrawingFDR_PEP(FDR,FDR_PEP,DecoyType,GroupType)

figure
plot(FDR.GF(DecoyType==1),FDR_PEP.combined,'r^')
hold on
plot(FDR.SF(DecoyType(GroupType==0)==1),FDR_PEP.separate,'b^')
plot(FDR.TF(DecoyType(GroupType==0)==1),FDR_PEP.trans,'g*')
plot(0:0.01:1,0:0.01:1,'k--')
% axis([0,0.1,0,0.1]);
end


