function [ratio_correct,ratio_incorrect] = EM_Difdis_pi(f1,A,pk,scores,maxiter)
% Ouputs:
%   a1,a2 - estimated weights
%   m - estimated mean vectors
%   v - estimated covariance matrices
%   a - estimated gamma shape parameter
%   b - estimated gamma location parameter
%   L - log likelihood of estimates
%   r - gamma move steps
%   the discriminant score distribution for correct peptide assignments
%   is initialized with that computed from the training data,which is
%   expected to be similar, although not identical, to that of most
%   datasets analyzed
%   in this part i used the gauss to cluster and set the first 5000
%   as the correct, the last as the incorrect


%%%% EM algorithm %%%%

%%%% the initialized %%%%
ct_prt = 0;
niter = 0;


% r = -quantile(scores,0.8);
% r = -min(scores);
% r = 0;
[ratio_correct,ratio_incorrect] = Initialize(scores);



while niter<=maxiter
    
    
    [r1,r2] = Expectation(ratio_correct,f1,A,pk);     % E-step
    [ratio_correct,ratio_incorrect] = Maximization(r1,r2);  % M-step
    niter = niter + 1;
    if rem(niter,200)==0 % then output process
        for j=1:ct_prt  
            fprintf('\b');  
        end
        ct_prt = fprintf('%i..',niter);
    end
end

for i=1:ct_prt  
    fprintf('\b');  
end
fprintf('%i..done.\n',niter);
end

%%%%%%%%%%%%%%%%%%%%%%
%%%% End of EM %%%%
%%%%%%%%%%%%%%%%%%%%%%



%%% calculate the scores %%%%
function [scores,DecoyType,I] = CalculateScoresTypes(result)
Scores = [result(:).Score];
[scores,I] = sort(Scores,'descend');
DecoyType = [result(I).DecoyType];
end



%%%% the initialized with that computed from the training data %%%%
%%%% select the global fdr<0.01 as correct, the remaining is incorrect
function [ratio_correct,ratio_incorrect] = Initialize(scores)



scores_change = scores;
position = find(scores>10000);
for i=1:length(position)
    scores_change(position(i))=scores(position(end)+1)+10;
end

incorrect = ceil(0.5*length(scores)):length(scores);
correct = 1:ceil(0.1*length(scores));


ratio_incorrect = length(incorrect)/length(scores);
ratio_correct = length(correct)/length(scores);

end
%%%% End of initialize %%%%

%%%% E-step %%%%
function [r1,r2] = Expectation(ratio_correct,f1,A,pk)
r1 = (ratio_correct*f1)./(ratio_correct*f1+A/pk);
r2 = (A/pk)./(ratio_correct*f1+A/pk);
end

% a1 = sum(r1)/N;
% a2 = sum(r2)/N;
%%%% End of E-step %%%%


%%%% M-step %%%%
function [ratio_correct,ratio_incorrect] = Maximization(r1,r2)
I = find(r1>=0);
II = find(r2>=0);
N = length(r1);
r1 = r1(I);
r2 = r2(II);

ratio_correct = sum(r1)/N;
ratio_incorrect = sum(r2)/N;
end

%%%% End of M-step %%%%
