function [f] = CorrectPDF(x,scores,h1,p)

sump = sum(p);
len = length(x);
f(1, len) =0;

parfor i = 1:len
    f(i) = p * exp(-(x(i) - scores).^2/(2*h1^2))';
end

f = f/(h1*sump*sqrt(2*pi));

end
