function [p,pi0,pi1,h0,h1,f00,f11] = SemiParametricFitting(Decoyscores,Targetscores,ems,ppi0,ppi1,hh1)

%%%%%%%%%%%%%%%%%%%%%Remove NAN%%%%%%%%%%%%%%%%%%%%%%%%%%%%
scores = Targetscores;
scores_change = scores;
position = find(scores>10000);
if ~isempty(position)
    for i=1:length(position)
        scores_change(position(i))=scores(position(end)+1)+10;
    end
end
scores = scores_change;
pi1 = ppi1;
pi0 = ppi0;
% Incorrect density fitted by decoy scores
[~,~,h0] = ksdensity(Decoyscores);
h1 = hh1;
p = ppi0*ones(1,length(scores));

f00 = IncorrectPDF(scores,Decoyscores,h0);
f11 = CorrectPDF(scores,scores,h1,1-p);


% EM Algorithm
Delta = 100;
i = 0;
while Delta>=ems
    i = i + 1;    
    pk = pi0*f00./(pi0*f00+pi1*f11);
    f11 = CorrectPDF(scores,scores,h1,1-pk);
    pi0 = mean(pk);
    pi1 = 1-pi0;
    pk_1 = pi0*f00./(pi0*f00+pi1*f11);
    delta = pk_1-pk;
    Delta = norm(delta,2);    
end

p = pk_1;


end