% GroupType: 0 is Group; 1 is nonGroup.
% DecoyType: 0 is Decoy; 1 is Target.
function [DecoyType,GroupType,scores,numrst,I] = JudgeGroup(result,TagType,DecoyTag,GroupTag)
Scores = [result(:).Score];
[scores,I] = sort(Scores,'descend');
numrst = numel(I);
Result = result(I);
DecoyType = zeros(1,length(Result));
GroupType = zeros(1,length(Result));

for i = 1:length(Result)  
%%%%%%%%%%%%%%%%%%%%%%%%%%Judge Target&Decoy%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    if strfind(upper(Result(i).protein),upper(DecoyTag))
        DecoyType(i) = 0;
    else
        DecoyType(i) = 1;
    end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%END%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%Judge the tag type��Protein or Modification%%%%%%%%%%%%%%%%%%%%
    if strcmpi(TagType,'Protein')
        if strfind(Result(i).protein,GroupTag)
            GroupType(i) = 0;
        else
            GroupType(i) = 1;
        end
    else
        if strcmpi(TagType,'Modification')
            if strfind(Result(i).modification,GroupTag)
                GroupType(i) = 0;
            else
                GroupType(i) = 1;
            end
        else
            if strcmpi(TagType,'ProteinSingle') || strcmpi(TagType,'SNP')
                if length(find(Result(i).protein==','))+1==length(strfind(Result(i).protein,GroupTag))
                    GroupType(i) = 0;
                else
                    GroupType(i) = 1;
                end
            end
        end
        
    end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%END%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

end

end



