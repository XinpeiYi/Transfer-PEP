function [F1,pi0A_1_F0A] = ComputeF_trans_CASE4(scores1,h1,p,P,pi0,F0,pk)

F1 = zeros(1,length(scores1));

for i = 1:length(scores1)
    F1(i) = length(scores1)*mean((1-p).*normcdf(scores1(i),scores1,h1))/sum(1-p);
end

rA = P(1)*scores1 + P(2);
pi0A_1_F0A =  rA*pi0.*(1-F0)/pk;

end