function [p,pi0,pi1,h1,f00,f11] = SemiParametricFitting_trans_CASE3(Targetscores,ems,ppi0,ppi1,hh1,f00)

%%%%%%%%%%%%%%%%%%%%%Remove NAN%%%%%%%%%%%%%%%%%%%%%%%%%
scores = Targetscores;
scores_change = scores;
position = find(scores>10000);
if ~isempty(position)
    for i=1:length(position)
        scores_change(position(i))=scores(position(end)+1)+10;
    end
end
scores = scores_change;
pi1 = ppi1;
pi0 = ppi0;

h1 = hh1;
p = ppi0*ones(1,length(scores));

f11 = CorrectPDF(scores,scores,h1,1-p);




% EM Algorithm
Delta = 100;
i = 0;

while Delta>=ems
    i = i + 1;
    p = pi0*f00./(pi0*f00+pi1*f11);
    f11 = CorrectPDF(scores,scores,h1,1-p);  
    pi0 = mean(p);
    pi1 = 1-pi0;
        
    p_1 = pi0*f00./(pi0*f00+pi1*f11);
    delta = p_1-p;
    Delta = norm(delta,2);
end

p = p_1;

end