function DrawingFDRfdr(FDR,FDRfdr,DecoyType,GroupType)

figure
plot(FDR.GF(DecoyType==1),FDRfdr.global,'r^')
hold on
plot(FDR.SF(DecoyType(GroupType==0)==1),FDRfdr.separate,'b^')
plot(FDR.TF(DecoyType(GroupType==0)==1),FDRfdr.trans,'g*')
plot(0:0.01:1,0:0.01:1,'k--')
% axis([0,0.1,0,0.1]);
end


