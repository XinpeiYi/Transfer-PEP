function [FDR] = ComputelocalFDR_trans_CASE4(pi1,pi0A_1_F0A,F1)

FDR = zeros(1,length(pi0A_1_F0A));
for i = 1:length(pi0A_1_F0A)
    if (pi0A_1_F0A(i)==0)&&(1-F1(i)==0)
        FDR(i)=0;
    else
        FDR(i) = pi0A_1_F0A(i)/(pi0A_1_F0A(i)+pi1*(1-F1(i)));
    end
        
end

end