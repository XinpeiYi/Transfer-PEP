function DrawingThreeFitting(Targetscores,TargetGroupType,Decoyscores,DecoyGroupType,h0,h1,pi0,pi1,p,f0,f1)

scores_group = Targetscores(TargetGroupType==0);
Decoyscores_group = Decoyscores(DecoyGroupType==0);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%combined%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
figure
x = Targetscores;
[bincounts.combined,bincenters.combined]=hist(x,50);
binwidth.combined = bincenters.combined(2) - bincenters.combined(1);
xx = 0:0.1:200;
f0_value = IncorrectPDF(xx,Decoyscores,h0.combined);
f1_value = CorrectPDF(xx,Targetscores,h1.combined,1-p.combined);

area0 = pi0.combined * length(x) * binwidth.combined;
area1 = pi1.combined * length(x) * binwidth.combined;
y0 = area0 * f0_value;
y1 = area1 * f1_value;

m1 = bar(bincenters.combined,bincounts.combined,[min(x),max(x)],'hist');
set(m1,'FaceColor','b')

axis([0,max(x),0,max(y0+y1)]);
hold on
l1 = plot(xx,y0,'r-.','LineWidth',2);
l2 = plot(xx,y1,'g-.','LineWidth',2);
l3 = plot(xx,y0+y1,'y-','LineWidth',2);
xlabel('mascot search score','fontsize',18,'fontweight','b');
ylabel('number of spectra','fontsize',18,'fontweight','b');
legend([l1 l2 l3], 'f0(x)', 'f1(x)','f(x)'); 


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%end%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%separate%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
figure
x = scores_group;
[bincounts.separate,bincenters.separate]=hist(x,50);
binwidth = bincenters.separate(2) - bincenters.separate(1);
xx = 0:0.1:200;
f0_value = IncorrectPDF(xx,Decoyscores_group,h0.separate);
% f1_value = CorrectPDF(xx,Targetscores,h1,1-p);
f1_value = CorrectPDF(xx,scores_group,h1.separate,1-p.separate);

area0 = pi0.separate * length(x) * binwidth;
area1 = pi1.separate * length(x) * binwidth;
y0 = area0 * f0_value;
y1 = area1 * f1_value;

m2 = bar(bincenters.separate,bincounts.separate,[min(x),max(x)],'hist');
set(m2,'FaceColor','b')

axis([0,max(x),0,max(y0+y1)]);
hold on
l1 = plot(xx,y0,'r-','LineWidth',2);
l2 = plot(xx,y1,'g-','LineWidth',2);
l3 = plot(xx,y0+y1,'y-','LineWidth',2);
xlabel('mascot search score','fontsize',12,'fontweight','b');
ylabel('number of spectra','fontsize',12,'fontweight','b');
legend([l1 l2 l3], 'f0(x)', 'f1(x)','f(x)');
hold off

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%end%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%difdis%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
figure
x = scores_group;
[bincounts,bincenters]=hist(x,50);
binwidth = bincenters(2) - bincenters(1);
xx = x;

f1_value = f1.trans;
f0_value = f0.trans;

area0 = pi0.trans * length(x) * binwidth;
area1 = pi1.trans * length(x) * binwidth;
y0 = area0 * f0_value;
y1 = area1 * f1_value;

m3 = bar(bincenters,bincounts,[min(x),max(x)],'hist');
set(m3,'FaceColor','b')
axis([0,max(x),0,max(y0+y1)]);
hold on
l1 = plot(xx,y0,'r-','LineWidth',2);
l2 = plot(xx,y1,'g-','LineWidth',2);
l3 = plot(xx,y0+y1,'y-','LineWidth',2);
xlabel('mascot search score','fontsize',12,'fontweight','b');
ylabel('number of spectra','fontsize',12,'fontweight','b');
legend([l1 l2 l3], 'f0(x)', 'f1(x)','f(x)');
hold off
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%end%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
end