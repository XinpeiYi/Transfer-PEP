function [fdr,FDR,Iid,Threshold,FinalFDR] = ComputePEP_CASE4(pi0,pi1,f0,f1,F0,F1,pi0A_1_F0A,I,fdrthres,GroupType,scores,numrst)
scores_group = scores(GroupType==0);

fdr.combined = (pi0.combined*f0.combined)./(pi0.combined*f0.combined+pi1.combined*f1.combined);
fdr.separate = (pi0.separate*f0.separate)./(pi0.separate*f0.separate+pi1.separate*f1.separate);
fdr.trans = (pi0.trans*f0.trans)./(pi0.trans*f0.trans+pi1.trans*f1.trans);

FDR.combined = (pi0.combined*(1-F0.combined))./(pi0.combined*(1-F0.combined)+pi1.combined*(1-F1.combined));
FDR.separate = (pi0.separate*(1-F0.separate))./(pi0.separate*(1-F0.separate)+pi1.separate*(1-F1.separate));
FDR.trans = (pi0A_1_F0A)./(pi0A_1_F0A+pi1.trans*(1-F1.trans));


J = (FDR.combined<=fdrthres);
if sum(J)==0
    Iid.combined = [];
    Threshold.combined = Inf;
else
    Threshold.combined = min(scores(J));
    Iid.combined = (  ~GroupType & scores>=Threshold.combined);
end
Iid.combined = I(Iid.combined);
if ~isempty(find(scores==Threshold.combined))
    FinalFDR.combined = min(FDR.combined(find(scores==Threshold.combined)));
else
    FinalFDR.combined = 1;
end

Iid.separate = zeros(1,numrst);
J = (FDR.separate<=fdrthres);
if sum(J)==0
    Threshold.separate = Inf;
else
    Threshold.separate = min(scores_group(J));
    Iid.separate = ( Iid.separate | ( scores>=Threshold.separate) );
end
Iid.separate = Iid.separate  & ~GroupType;
Iid.separate = I(Iid.separate);
if ~isempty(find(scores_group==Threshold.separate))
    FinalFDR.separate = min(FDR.separate(find(scores_group==Threshold.separate)));
else
    FinalFDR.separate = 1;
end

Iid.trans = zeros(1,numrst);
J = (FDR.trans<=fdrthres);
if sum(J)==0
    Threshold.trans = Inf;
else
    Threshold.trans = min(scores_group(J));
    Iid.trans = ( Iid.trans | ( scores>=Threshold.trans) );
end
Iid.trans = Iid.trans  & ~GroupType;
Iid.trans = I(Iid.trans);
if ~isempty(find(scores_group==Threshold.trans))
    FinalFDR.trans = min(FDR.trans(find(scores_group==Threshold.trans)));
else
    FinalFDR.trans = 1;
end


end