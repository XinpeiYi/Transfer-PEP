function [f] = IncorrectPDF(x,scores,h0)
p = ones(1,length(scores));
f = CorrectPDF(x,scores,h0,p);
end