function [result] = ReadDatResultFolder(path)

result = [];
datafiles = dir(fullfile(path,'*.dat'));
nfiles = length(datafiles);
for i=1:nfiles
    plfilepath = fullfile(path,datafiles(i).name);
    disp(['Reading ' plfilepath '...']);
    [resulti] = ReadDatResult(plfilepath);   
    result = [result resulti];%combine 1��nfiles   
end

end