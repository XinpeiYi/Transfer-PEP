function [ratio_correct,ratio_incorrect] = EM_Change_Pi(f00,f11,scores,maxiter)

%%%% the initialized %%%%
ct_prt = 0;
niter = 0;

[ratio_correct,ratio_incorrect] = Initialize(scores);



while niter<=maxiter
    
    
    [r1,r2] = Expectation(ratio_correct,ratio_incorrect,f00,f11);     % E-step
    [ratio_correct,ratio_incorrect] = Maximization(r1,r2);
    niter = niter + 1;
    if rem(niter,200)==0 % then output process
        for j=1:ct_prt  
            fprintf('\b');  
        end
        ct_prt = fprintf('%i..',niter);
    end
end

for i=1:ct_prt  
    fprintf('\b');  
end
fprintf('%i..done.\n',niter);
end

%%%%%%%%%%%%%%%%%%%%%%
%%%% End of EM %%%%
%%%%%%%%%%%%%%%%%%%%%%


%%%% the initialized with that computed from the training data %%%%
function [ratio_correct,ratio_incorrect] = Initialize(scores)

scores_change = scores;
position = find(scores>10000);
for i=1:length(position)
    scores_change(position(i))=scores(position(end)+1)+10;
end

incorrect = ceil(0.5*length(scores)):length(scores);
correct = 1:ceil(0.1*length(scores));


ratio_incorrect = length(incorrect)/length(scores);
ratio_correct = length(correct)/length(scores);

end

%%%% E-step %%%%
function [r1,r2] = Expectation(ratio_correct,ratio_incorrect,f00,f11)
r1 = (ratio_correct*f11)./(ratio_correct*f11+ratio_incorrect*f00);
r2 = ratio_incorrect*f00./(ratio_correct*f11+ratio_incorrect*f00);
end

%%%% End of E-step %%%%


%%%% M-step %%%%
function [ratio_correct,ratio_incorrect] = Maximization(r1,r2)
I = find(r1>=0);
II = find(r2>=0);
N = length(r1);
r1 = r1(I);
r2 = r2(II);

ratio_correct = sum(r1)/N;
ratio_incorrect = sum(r2)/N;
end

%%%% End of M-step %%%%





