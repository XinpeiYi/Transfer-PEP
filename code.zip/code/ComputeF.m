function [F0,F1] = ComputeF(scores1,scores2,h0,h1,p)

F0 = zeros(1,length(scores1));
F1 = zeros(1,length(scores1));
parfor i = 1:length(scores1)
    F0(i) = mean(normcdf(scores1(i),scores2,h0));
end
parfor i = 1:length(scores1)
    F1(i) = length(scores1)*mean((1-p).*normcdf(scores1(i),scores1,h1))/sum(1-p);
end

end