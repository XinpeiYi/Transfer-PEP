function [FDR] = ComputelocalFDR_trans_CASE3(pi0,pi1,F0,F1)

FDR = zeros(1,length(F0));
for i = 1:length(F0)
    if (1-F0(i)==0)&&(1-F1(i)==0)
        FDR(i)=0;
    else
        FDR(i) = pi0*(1-F0(i))/(pi0*(1-F0(i))+pi1*(1-F1(i)));
    end
        
end


end